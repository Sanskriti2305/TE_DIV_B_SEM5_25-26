# This will run when you click "Start" in the UI.
# You can replace this logic with your actual gaze typing implementation.

import time

print("GazeType started.")
for i in range(3):
    print(f"Working... {i+1}")
    time.sleep(1)
print("GazeType completed.")
